import time


#This is just used to make it look nicer and smooth the flow of the code.
def loadingCode():
    time.sleep(1.0)
    print("\n===================================")
    print("             Loading...    ʕ•́ᴥ•̀ʔっ")
    print("===================================\n")
    time.sleep(1.0)


#This is used to loop the program back towards the start whenever the user agrees to.
def codeStart():
    itemChoice = 0
    print("\nWhat can I get for you again?\n")
    print("\nWhat would you like?\n")
    time.sleep(1.0)
    print("\nC- Clothes, F- Food, V- Video Games, R- Rare Collectibles\n")
    time.sleep(2.0)
    items = input(
        "\nType in one of the letters corresponding to the item type.\n"
    ).lower()
    itemList(items)
    print("Which of these would you want more information on?\n")
    time.sleep(1.5)
    itemChoice = input(
        "Pick a number from 1-5 according to the order of the items presented to know more about it.\n"
    ).lower()
    itemInfo(items, itemChoice)
    confirm(itemChoice)
    shopAgain()


#This asks the name for the user and loops until they provide answer 'yes' to the last question.
def askName():
    print("What is your name?\n")
    time.sleep(1.0)
    userName = input("Please input a valid name.\n")
    time.sleep(1.0)
    print(userName + " is your name, correct?\n")
    time.sleep(1.0)
    confirmName = input("\nPlease select either 'yes' or 'no'.\n").lower()
    time.sleep(1.0)
    if confirmName == "yes":
        print("\nAlright! Awesome, nice to meet you, " + userName +
              " , I'm Bob.\n")
    while confirmName == "no":
        print("\nStop messing around with me. What is your name?\n")
        time.sleep(1.0)
        userName = input("\nPlease input a valid name.\n")
        time.sleep(1.0)
        print(userName + " is your name, correct?")
        confirmName = input("\nPlease select either 'yes' or 'no'.\n").lower()
        if confirmName == "yes":
            time.sleep(0.5)
            print("\nAlright! Awesome, nice to meet you, " + userName +
                  " , I'm Bob.\n")


#Usage of lists displaying variety of items.
Clothes = [
    "Raggedy Cloth ", "Used Sweatpants ", "Oversized Hoodie ",
    "Slightly-Stained T-Shirt ", "Used Sock"
]
Food = [
    "Moldly Bread ", "Thin-Slice of Pizza ", "Can of Beans ", "Chewed Gum ",
    "Frozen Fish"
]
VideoGames = ["Mario 64 ", "Tetris ", "Fortnite ", "Minecraft ", "Roblox"]
RareCollect = [
    "Antique Coin ", "Ancient Shiny Pot ", "Golden Ring ",
    "First-edition Shiny Charizard Card ", "Rare Mystery Figurine"
]

#Greetings, first code that introduces users.
print("===================================")
print("Greetings, welcome to Bob's Garage!")
print("===================================\n")
time.sleep(1.0)
askName()
print("We have all sorts of wares. What would you like?\n")
time.sleep(1.0)
print("\nC- Clothes, F- Food, V- Video Games, R- Rare Collectibles\n")
time.sleep(1.5)
items = input(
    "\nType in one of the letters corresponding to the item type.\n").lower()


#This function decides and displays the choices the user picks.
def itemList(items):
    if items == "c":
        print(
            "Getting a little cold today, huh? Here's what we have today:\n" +
            str(Clothes))
    if items == "f":
        print("A little hungry now? Take a look at what we have today:\n" +
              str(Food))
    if items == "v":
        print("A gamer, I see. Check these out:\n" + str(VideoGames))
    if items == "r":
        print("Going for the golden loot? Awesome, here's what we have:\n" +
              str(RareCollect))
    while items != "c" or "f" or "v" or "r":
        items = input("\nPlease enter either 'c', 'f', 'v', or 'r'.\n")
        if items == "c":
            print(
                "Getting a little cold today, huh? Here's what we have today:\n"
                + str(Clothes))
            break
        if items == "f":
            print("A little hungry now? Take a look at what we have today:\n" +
                  str(Food))
            break
        if items == "v":
            print("A gamer, I see. Check these out:\n" + str(VideoGames))
            break
        if items == "r":
            print(
                "Going for the golden loot? Awesome, here's what we have:\n" +
                str(RareCollect))
            break


itemList(items)

loadingCode()

print(
    "What an amazing array of items! Which of these would you want more information on?\n"
)
time.sleep(1.5)
itemChoice = input(
    "Pick a number from 1-5 according to the order of the items presented to know more about it.\n"
).lower()


#More functions that are used in order to display the information of the items and further prompts users to select a boolean choice.
def itemInfo(items, itemChoice):
    while items == "c":
        if itemChoice == "1":
            print(
                "These " + Clothes[0] +
                " is sort of used and tattered, but still wearable. This will cost you $5, a discount just for you."
            )
            break
        if itemChoice == "2":
            print(
                "These " + Clothes[1] +
                " are actually kind of sweaty, but you can manage with it, right? It's only $8."
            )
            break
        if itemChoice == "3":
            print(
                "This " + Clothes[2] +
                " are probably too big for you, but it's $15. Take it or leave it."
            )
            break
        if itemChoice == "4":
            print("Uh... who knows whats on this " + Clothes[3] +
                  "... It's $8, though! Haha...")
            break
        if itemChoice == "5":
            print("Okay... I don't know why you would want this " +
                  Clothes[4] + ", but it's $2.")
            break
    while items == "f":
        if itemChoice == "1":
            print(
                "This " + Food[0] +
                " seems like it has been sitting here for a while... I'll sell it to ya for $1."
            )
            break
        if itemChoice == "2":
            print(
                "This here " + Food[1] +
                " doesn't have much cheese on it, but it'll probably be tasty at least. This'll cost $3."
            )
            break
        if itemChoice == "3":
            print(
                "The holy grail of all food items here: " + Food[2] +
                "! This will cost you $20. Take it or leave it, your choice, bud."
            )
            break
        if itemChoice == "4":
            print(
                "Uh... this piece of " + Food[3] +
                " was from this morning. I'll offer you $0.50 for it, capiche?"
            )
            break
        if itemChoice == "5":
            print("This " + Food[4] +
                  " still seems pretty fresh, I think. $5 per pound.")
            break
    while items == "v":
        if itemChoice == "1":
            print("A classic game!" + VideoGames[0] + " will cost you $15.")
            break
        if itemChoice == "2":
            print("A retro game, I see. Interested? " + VideoGames[1] +
                  " is only $10!")
            break
        if itemChoice == "3":
            print(VideoGames[2] + " huh... That'll be $60. Heh-heh...")
            break
        if itemChoice == "4":
            print(
                "Oh, " + VideoGames[3] +
                "! This is a fantastic game. Ever heard of it? It's amazing. It'll be $28, though."
            )
            break
        if itemChoice == "5":
            print("An oof-inducing game, " + VideoGames[4] +
                  "! That'll be $5...")
            break
    while items == "r":
        if itemChoice == "1":
            print("No idea where this originates from, but this " +
                  RareCollect[0] + " will only be, let's see... $3? Yeah, $3.")
            break
        if itemChoice == "2":
            print("This " + RareCollect[1] +
                  " is pretty old and of ancient descent. I'll make it $35.")
            break
        if itemChoice == "3":
            print("Well, this " + RareCollect[2] +
                  " is golden... so... $100, perhaps?")
            break
        if itemChoice == "4":
            print("Woah! A keen eye you have there. This " + RareCollect[3] +
                  " is extremely rare. That'll cost ya $500.")
            break
        if itemChoice == "5":
            print("Erm... not sure what this " + RareCollect[4] +
                  " is but, if you want it, it'll be $5, I guess.")
            break


itemInfo(items, itemChoice)


#Another boolean function where users answer with one answer of the two in order to further the code.
def confirm(itemChoice):
    print("\nNice choice, would you like to purchase this item?\n")
    time.sleep(1.0)
    purchase = input("\nPlease select either 'yes' or 'no'.\n").lower()
    if purchase == "yes":
        print("\nDo you want a bag with that?\n")
        loadingCode()
        bag = input("\nPlease select either 'yes' or 'no'.\n").lower()
        if bag == "yes":
            loadingCode()
            print("Thank you very much, partner! Enjoy your new item!")
        if bag == "no":
            loadingCode()
            print("Alright then. Enjoy your new item!")
    if purchase == "no":
        loadingCode()
        print("Oh, okay. Would you like to get something else instead")
        query = input("Please select either 'yes' or 'no'.\n").lower()
        if query == "yes":
            codeStart()
        if query == "no":
            loadingCode()
            print("Sorry about that! Thanks for coming.")
            exit()


time.sleep(1.0)
confirm(itemChoice)


#This function will allow users to loop the program and code back towards the beginning until they say 'no'.
def shopAgain():
    print("\nBefore you go, do you want to continue shopping?\n")
    time.sleep(1.0)
    moreItems = input("Please select either 'yes' or 'no'.\n").lower()
    if moreItems == "yes":
        codeStart()
    if moreItems == "no":
        loadingCode()
        print(
            "Alright, then. Thank you for coming by! Please come again. Remember, we have all sorts of fantastic and wacky items every week!"
        )
        exit()


shopAgain()
